// 
// 
// 

#include "LED_handheld_behaviour.h"

Led_handheld_behaviour::Led_handheld_behaviour()
{
	Led_handheld_behaviour_init();
}

void Led_handheld_behaviour::Led_handheld_behaviour_init()
{
	voltage_init();
	humid_temp_init();
	sd_init();
}

bool Led_handheld_behaviour::record(int freq)
{
	switch (sd_state)
	{
	case file_set:
	{
		set_file();
		break;
	}
	case record_start:
	{
		start_record(freq);
		break;
	}
	case record_loop:
	{
		loop_record();
		break;
	}
	case record_stop:
	{
		save_record();
		return true;
		break;
	}
	default:
		break;
	}
	return false;
}

bool Led_handheld_behaviour::record(int freq, int dur)
{
	switch (sd_state)
	{
	case file_set:
	{
		set_file();
		break;
	}
	case record_start:
	{
		duration = millis() + 1000 * dur;
		start_record(freq);
		break;
	}
	case record_loop:
	{
		loop_record();
		if (millis() >= duration)
		{
			sd_state = record_stop;
		}
		break;
	}
	case record_stop:
	{
		save_record();
		return true;
		break;
	}
	default:
		break;
	}
	return false;
}

void Led_handheld_behaviour::stop_record()
{
	stop_loop = true;
}

bool Led_handheld_behaviour::serial_print(int freq)
{
	period = 1000000 / freq;
	timestamp = rtc.now();
	if (before_now <= micros())
	{
		before_now = micros() + period;
		Serial.println(serial_print_data());
	}
	return true;
}

bool Led_handheld_behaviour::import_all_files()
{
	String rootpath = "/";
	File root;
	root = sd.open("/");
	import_files(root, rootpath);
}

bool Led_handheld_behaviour::import_files(File dir, String tempPath)
{
	while (true) {
		File entry = dir.openNextFile();
		String localPath;

		char dir_name[200];
		size_t dir_len = 200;
		char file_name[100];
		size_t file_len = 100;
		String datatemp;

		String rootpath = "/";

		if (entry) {
			if (entry.isDirectory())
			{
				entry.getName(dir_name, dir_len);
				delay(10);
				Serial.println("1");
				delay(10);
				Serial.println(tempPath + dir_name);
				localPath = tempPath + dir_name + rootpath + '\0';
				char folderBuf[localPath.length()];
				localPath.toCharArray(folderBuf, localPath.length());
				import_files(entry, folderBuf);
			}
			else
			{
				entry.getName(file_name, file_len);
				localPath = tempPath + file_name + '\0';
				char charBuf[localPath.length()];
				localPath.toCharArray(charBuf, localPath.length());

				if (strstr(file_name, ".csv"))
				{
					delay(10);
					Serial.println("2");
					delay(10);
					Serial.println(file_name);
					File dataFile = sd.open(charBuf);
					if (dataFile) {
						delay(10);
						Serial.println("3");
						delay(10);
						while (dataFile.available()) {
							char filedata = (char) dataFile.read();
							if (filedata == '\r')
							{
//								if(datatemp.length()>0)
									Serial.println(datatemp);
								datatemp = "";
							}
							else
							{
								String str;
								str = String(filedata);
								char b[5];
								str.toCharArray(b, 2);
								datatemp += (String) b;
//								datatemp += (filedata - '0');
							}
						}
						dataFile.close();
						delay(10);
						Serial.println("4");
					}
				}
			}
		}
		else {
			break;
		}
	}
	Serial.println("5");
	return true;
}

bool Led_handheld_behaviour::memory_info()
{
	Serial.println("1");
	delay(50);
	free_space_val();
	delay(50);
	Serial.println("2");
	delay(50);
	max_space_val();
	delay(50);
	Serial.println("3");
	return true;
}

bool Led_handheld_behaviour::remove_all_files()
{
	String rootpath = "/";
	File root;
	root = sd.open("/");
	remove_files(root, rootpath);
}

bool Led_handheld_behaviour::remove_files(File dir, String tempPath)
{
	while (true) {
		File entry = dir.openNextFile();
		String localPath;
		char dir_name[200];
		size_t dir_len=200;
		char file_name[100];
		size_t file_len=100;

		String rootpath = "/";

		if (entry) {
			if (entry.isDirectory())
			{
				entry.getName(dir_name, dir_len);
				localPath = tempPath + dir_name + rootpath + '\0';
				char folderBuf[localPath.length()];
				localPath.toCharArray(folderBuf, localPath.length());
				remove_files(entry, folderBuf);

				sd.rmdir(folderBuf);
			}
			else
			{
				entry.getName(file_name, file_len);
				localPath = tempPath + file_name + '\0';
				char charBuf[localPath.length()];
				localPath.toCharArray(charBuf, localPath.length());

				sd.remove(charBuf);
			}
		}
		else {
			break;
		}
	}
	Serial.println("1");
	return true;
}

void Led_handheld_behaviour::save_record()
{
	data_file.close();
	sd_state = file_set;
}

void Led_handheld_behaviour::loop_record()
{
	timestamp = rtc.now();
	if (before_now <= micros())
	{
		before_now = micros() + period;
		data_file.println(serial_print_data());
		data_iter++;
	}

	if (stop_loop)
	{
		sd_state = record_stop;
		stop_loop = false;
	}
	else
	{
		sd_state = record_loop;
	}
}

void Led_handheld_behaviour::start_record(int freq)
{
	data_iter = 1;
	before_now = 0;
	period = 1000000 / freq;
	if (data_file)
	{
		String coba_string = (String)"Device Id" + ", " + ": " + ", " + String(device_id);
		data_file.println(coba_string);
		data_file.println((String)"Operator" + ", " + ": " + ", " + operator_id);
		data_file.println((String)"Time" + ", " + ": " + ", " + date + "_" + timestamp.year());
		data_file.println("");

		data_file.println((String)"No" + "," + "Timestamp" + "," + "Temperature" + "," + "Humidity" + "," + "V1" + "," + "V2" + "," + "V3" + "," +
			"V4" + "," + "V5" + "," + "V6" + "," + "V7" + "," + "V8" + "," + "V9" + "," + "Vref1" + "," + "V1ref2" +
			"," + "Vout1" + "," + "Vout2" + "," + "Vout3");
		sd_state = record_loop;
	}
	else
		Serial.println("can't open file");
}

void Led_handheld_behaviour::set_file()
{
	timestamp = rtc.now();
	date = (String)timestamp.day() + "_" + month[timestamp.month() - 1];
	if (!sd.exists(date))
		sd.mkdir(date);
	file_num = 0;
	filename = (String)date + "/" + file_num + ".csv";
	while (sd.exists(filename))
	{
		data_file.close();
		file_num++;
		filename = (String)date + "/" + file_num + ".csv";
	}
	data_file = sd.open(filename, FILE_WRITE);
	Serial.println("print to" + filename);
	sd_state = record_start;
}

String Led_handheld_behaviour::serial_print_data()
{
	double max_sensor_voltage = 25.0;
	String data = String(data_iter) + "," + String(timestamp.hour()) + " : " + String(timestamp.minute()) + " : " + String(timestamp.second()) + ", "
		+ String(gettemp_C()) + ", " + String(gethumid()) + ", "
		+ String(getvoltage(V1, max_sensor_voltage)) + ", "
		+ String(getvoltage(V2, max_sensor_voltage)) + ", "
		+ String(getvoltage(V3, max_sensor_voltage)) + ", "
		+ String(getvoltage(V4, max_sensor_voltage)) + ", "
		+ String(getvoltage(V5, max_sensor_voltage)) + ", "
		+ String(getvoltage(V6, max_sensor_voltage)) + ", "
		+ String(getvoltage(V7, max_sensor_voltage)) + ", "
		+ String(getvoltage(V8, max_sensor_voltage)) + ", "
		+ String(getvoltage(V9, max_sensor_voltage)) + ", "
		+ String(getvoltage(Vref1, max_sensor_voltage)) + ", "
		+ String(getvoltage(Vref2, max_sensor_voltage)) + ", "
		+ String(getvoltage(Vout1, max_sensor_voltage)) + ", "
		+ String(getvoltage(Vout2, max_sensor_voltage)) + ", "
		+ String(getvoltage(Vout3, max_sensor_voltage)) + ", ";

	return data;
}

void Led_handheld_behaviour::free_space_val()
{
	uint32_t freeClusters = sd.vol()->freeClusterCount();
	double freeGB = (double) 0.512 * freeClusters * sd.vol()->blocksPerCluster()/(1024.0*1024.0);
	Serial.println(freeGB);
}

void Led_handheld_behaviour::max_space_val()
{
	uint32_t space = sd.vol()->clusterCount();
	space *= sd.vol()->blocksPerCluster();
	double sizeGB = (double)space / (2024.0 * 1024.0);
	Serial.println(sizeGB);
}

void Led_handheld_behaviour::sd_init()
{
	pinMode(CS_PIN, OUTPUT);
	if (!sd.begin())
	{
		Serial.println("gagal");
		return;
	}
}

void Led_handheld_behaviour::rtc_init()
{
	Wire.begin();
	if (!rtc.begin())
	{
		Serial.println("couldn't find RTC");
		rtc.begin();
		while (1) {
			if (rtc.begin())
				break;
		}
	}
}


double Led_handheld_behaviour::gethumid()
{
	return dht_sensor.readHumidity();
}

double Led_handheld_behaviour::gettemp_C()
{
	return dht_sensor.readTemperature();
}

double Led_handheld_behaviour::gettemp_F()
{
	return dht_sensor.readTemperature(true);
}


void Led_handheld_behaviour::humid_temp_init() 
{
	dht_sensor.begin();
}



double Led_handheld_behaviour::getvoltage(int voltage_number, double max_voltage)
{
	double value = analogRead(voltage_number);
	return value * DCA_Vscale * max_voltage;
}

void Led_handheld_behaviour::voltage_init()
{
	for (int i = 83; i <= 97; i++)
		pinMode(i, INPUT);
}