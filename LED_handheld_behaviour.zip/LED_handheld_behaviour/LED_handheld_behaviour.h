// LED_handheld_behaviour.h

/*Dependencies
	- SdFat
	- DHT sensor Library
	- RTClib
	- Wire
	*/

#ifndef _LED_HANDHELD_BEHAVIOUR_h
#define _LED_HANDHELD_BEHAVIOUR_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include<DHT.h>

#include <RTClib.h>
#include <Wire.h>
#include <SPI.h>

#include <SdFat.h>


#define V1 (A0)
#define V2 (A1)
#define V3 (A2)
#define V4 (A3)
#define V5 (A4)
#define V6 (A5)
#define V7 (A6)
#define V8 (A7)
#define V9 (A8)
#define Vref1 (A9)
#define Vref2 (A10)
#define Vout1 (A11)
#define Vout2 (A12)
#define Vout3 (A13)

#define CS_PIN 10

#define DCA_Vscale 1.0/1024.0

enum state
{
	file_set, record_start, record_loop, record_stop
};

class Led_handheld_behaviour
{
public:
	Led_handheld_behaviour();
	void Led_handheld_behaviour_init();

	int device_id = 1000;
	int operator_id = 1010;

	/**
	* @brief a function to save data in sd card
	* @param freq - recorded data frequency
	* @return true if the process are stopped manually
	*/
	bool record(int freq);
	/**
	* @brief a function to save data in sd card
	* @param freq - recorded data frequency
	* @param dur - record duration
	* @return true if the process are stopped with specified duration/manually stoped
	*/
	bool record(int freq, int dur);
	/**
	* @brief a function to serial print the sensor data
	* @param freq - update frequency
	* @return true if the process success
	*/
	bool serial_print(int freq);
	/**
	* @brief a function to stop the recording process
	*/
	void stop_record();

	/**
	* @brief a function to copy data from sd card to other memory
	* @return true if process are successfully executed
	*/
	bool import_all_files();

	/**
	* @brief remove all files
	* @return true when the process finished
	*/
	bool remove_all_files();

	/**
	* @brief print the memory data (free and max capacity)
	* @return true when the process finished
	*/
	bool memory_info();

//sd card stuff
private:
	SdFat sd;
	state sd_state;

	bool stop_loop = false;

	File data_file;
	String filename;
	String date;
	int file_num;

	int data_iter;

	String month[12] = {
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
	};

	void sd_init();

	/**
	* @brief function for print sensor data with specified format
	* @return string with the sensor data
	*/
	String serial_print_data();

	/**
	* @brief setting the filename for saving purpose
	*/
	void set_file();
	/**
	* @brief preparation
	* @param set the update freq
	*/
	void start_record(int freq);
	/**
	* @brief loop process
	*/
	void loop_record();
	/**
	* @brief close and save the incoming data into .csv file
	*/
	void save_record();
	/**
	* @brief print free space in sd
	*/
	void free_space_val();
	/**
	* @brief print max sd space
	*/
	void max_space_val();
	/**
	* @brief remove data with specified direcotry
	* @return true when the process finished
	*/
	bool remove_files(File dir, String tempPath);

	/**
	* @brief a function to copy specified data to other memory
	* @param dir - specific directory to copy
	* @param temPpath - path for buffer
	* @return true if process are successfully executed
	*/
	bool import_files(File dir, String tempPath);


//RTC stuff
public:
	RTC_DS3231 rtc;
//	RTC_DS1307 rtc;
	void rtc_init();
private:
	DateTime timestamp;
	unsigned long duration;
	unsigned long before_now;
	unsigned long period;


//temperature and humidity sensor stuff
private:
	DHT dht_sensor = DHT(2,DHT11);
	
	void humid_temp_init();

	/**
	* @brief a function to get the humidity value
	* @return humidity value
	*/
	double gethumid();

	/**
	* @brief a function to get the temperature value in Celsius
	* @return temperature value in Celsius
	*/
	double gettemp_C();
	
	/**
	* @brief a function to get the temperature value in Fahrenheit
	* @return temperature value in Fahrenheit
	*/
	double gettemp_F();

//voltage sensor stuff
//private:
	void voltage_init();
	
	/**
	* @brief a function to get the voltage value
	* 
	* @param voltage_name - fill with the desired voltage name
	* @param sensor_scale - fill with voltage sensor scale (max_v/5)
	* 
	* @return voltage value
	*/
	double getvoltage(int voltage_name, double sensor_scale);
};

#endif

